package com.example.tp3
const val url = "https://8aaa-129-45-35-138.eu.ngrok.io"