package com.example.tp3.Entites

data class Utilisateur (
    var id_utilisateur:Int,
    var email:String,
    var numero_telephone:String,
    var nom:String,
    var prenom:String,
    var mot_de_passe:String,

)